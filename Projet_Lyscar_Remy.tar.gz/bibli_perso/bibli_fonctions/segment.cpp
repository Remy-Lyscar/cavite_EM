#include"bibli_fonctions.h"
void segment(double xa,double ya,double xb,double yb,fstream &fich)
{
  fich << endl;
  fich << xa << " " << ya << endl << xb << " " << yb << endl;
}
